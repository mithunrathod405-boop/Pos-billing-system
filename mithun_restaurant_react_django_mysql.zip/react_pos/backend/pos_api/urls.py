from django.urls import path
from . import views
urlpatterns=[path('auth/',views.auth_api),path('products/',views.products_api),path('orders/',views.orders_api),path('order/',views.order_api),path('settings/',views.settings_api)]
